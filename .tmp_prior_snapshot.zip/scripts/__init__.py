"""Script helpers."""

